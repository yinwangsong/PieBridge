@echo off
setlocal
cd /d "%~dp0"
latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main-clean.tex
if errorlevel 1 exit /b 1
latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main.tex
if errorlevel 1 exit /b 1
copy /Y "build\main-clean.pdf" "PETCube_TMC_clean.pdf" >nul
if errorlevel 1 exit /b 1
copy /Y "build\main.pdf" "PETCube_TMC_marked.pdf" >nul
if errorlevel 1 exit /b 1
echo Built PETCube_TMC_clean.pdf and PETCube_TMC_marked.pdf
