#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main-clean.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main.tex
cp build/main-clean.pdf PETCube_TMC_clean.pdf
cp build/main.pdf PETCube_TMC_marked.pdf
