PETCube — TMC LaTeX source package

本包对应当前 16 页 TMC 稿件，含所需正文、参考文献、图片和模板文件。
作者姓名为 Gang Huang；通讯作者为 Mengwei Xu。
Cover letter 位于 cover_letter/，落款为 Wangsong Yin。

编译入口
  main-clean.tex：正式稿，修订文字为黑色。
  main.tex：保留蓝色新增内容的标注稿。

Overleaf
  上传本 ZIP 新建项目，编译器选择 pdfLaTeX。
  Main document 选择 main-clean.tex（正式稿）或 main.tex（标注稿）。
  两个入口使用同一套正文、参考文献和图片。

Windows 本地编译
  安装包含 latexmk、pdfLaTeX、BibTeX 和常用宏包的 TeX Live。
  解压后双击 build.bat，同时编译正式稿与标注稿。
  输出 PETCube_TMC_clean.pdf、PETCube_TMC_marked.pdf。
  或在本目录的 PowerShell 中执行：
    latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main-clean.tex
    latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main.tex

Linux / macOS
  在已安装 LaTeX 工具链的环境中执行 bash build.sh。

投稿信
  在 cover_letter 目录执行：
    latexmk -pdf -interaction=nonstopmode -halt-on-error cover_letter_tmc.tex

IEEEtran.cls、IEEEtran.bst、algorithm2e.sty 随包提供，保留上游文件内容。
figs/ 和 figures/ 中的 PDF 是正文所需的矢量图片，不是整篇论文预览。
orin_period_sweep.py 和对应 JSON 是最终柱状图的绘图源码与汇总数据。
不包含编译日志、缓存、旧版示例图、预览导出、实验原始记录、模型或数据集。
source_manifest.json 记录包内文件的 SHA-256。
